package main;

import java.util.List;
import java.util.ArrayList;

public final class ImmutableClass {

	// Properties
	private final String SCIENTIFIC_NAME; 
	private final String POPULAR_NAME;
	private final int AGE;
	private final double MASS;
	private final List<String> HABITAT;



	// Constructores metodo virtual
	public ImmutableClass(String SCIENTIFIC_NAME, String POPULAR_NAME, int AGE, double MASS,List<String> HABITAT) {
		this.SCIENTIFIC_NAME = SCIENTIFIC_NAME;
		this.POPULAR_NAME = POPULAR_NAME;
		this.AGE = AGE;
		this.MASS = MASS;
		this.HABITAT = new ArrayList<>(HABITAT);
	}

	@Override
	public String toString() {
		String subInfo = 
				"\nSCIENTIFIC_NAME=" + this.SCIENTIFIC_NAME + 
				"\nPOPULAR_NAME=" + this.POPULAR_NAME + 
				"\nAGE=" + this.AGE +
				"\nMASS=" + this.MASS + 
				"\nLista="+this.HABITAT+
				"";
		return subInfo;
	}
	
	/**
	 * @return the SCIENTIFIC_NAME
	 */
	public List<String> getHABITAT() {
		return new ArrayList<>(HABITAT);
	}

	/**
	 * @return the SCIENTIFIC_NAME
	 */
	public String getSCIENTIFIC_NAME() {
		return SCIENTIFIC_NAME;
	}

	/**
	 * @return the POPULAR_NAME
	 */
	public String getPOPULAR_NAME() {
		return POPULAR_NAME;
	}

	/**
	 * @return the AGE
	 */
	public int getAGE() {
		return AGE;
	}

	/**
	 * @return the MASS
	 */
	public double getMASS() {
		return MASS;
	}

	// behaviors


}
