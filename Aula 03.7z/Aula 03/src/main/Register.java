package main;

import java.util.List;
import java.util.ArrayList;

public record Register(String SCIENTIFIC_NAME, String POPULAR_NAME, int AGE, double MASS,List<String> HABITAT) {
	
	/*
	 * public Register { HABITAT = new ArrayList<>(HABITAT); }
	 */
	
	
	//cópia defensiva....
	@Override
	public List<String> HABITAT(){
		
		return new ArrayList<>(HABITAT);
	}
	
	@Override
	public String toString() {
		String subInfo="\nscientificName=" +SCIENTIFIC_NAME + 
				"\npopularName=" + POPULAR_NAME + 
				"\nage=" + AGE + "\nmass="+ MASS +
				"\nlista="+HABITAT+
				"";
		return subInfo;
	}
}
