package main;

public class GenericClass <Type>{
	
	//Properties
	private Type password;
	
	//Constructors
	public GenericClass() {
	}
	
	public GenericClass(Type password) {
		this.password=password;
	}
	
	//Behaviors
	public Type getPassword()
	{
	
		return password;
	}
	
	public void setPassword(Type password) {
		
		this.password=password;
	}
	}
