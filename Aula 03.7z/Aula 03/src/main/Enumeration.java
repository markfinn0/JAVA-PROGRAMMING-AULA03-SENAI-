package main;

public enum Enumeration {

	// Objects
	ENUM_OBJECT_1 (123,"Texto"),// é equivalente a uma instância de uma classe, o que está dentro dos parenteses são os parametros...
	
	ENUM_OBJECT_2 (456,"TEXTO2"),
	
	ENUM_OBJECT_3 (789,"TEXTO3")
	;
	
	
	// Properties
	private final int value1;
	private final String value2;
	
	Enumeration(int value1) {
		this.value1=value1;
		value2="texto2";
		
	}
	
	// Constructors
	Enumeration(int value1,String value2) {
		this.value1=value1;
		this.value2=value2;
		
	}

	/**
	 * @return the value1
	 */
	public int getValue1() {
		return value1;
	}

	/**
	 * @return the value2
	 */
	public String getValue2() {
		return value2;
	}
	
	// Behaviors
	
	
}
