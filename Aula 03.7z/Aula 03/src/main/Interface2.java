package main;
import main.Interface1;

public interface Interface2 extends Interface1{
	
	
}
