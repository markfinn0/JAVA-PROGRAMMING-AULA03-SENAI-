package samples.animal;

public abstract class Amphibian extends Chordate implements Aquatic,Terrestrial {

}
