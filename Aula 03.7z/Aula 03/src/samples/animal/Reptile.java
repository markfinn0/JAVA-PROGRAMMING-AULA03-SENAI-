package samples.animal;

public abstract class Reptile extends Chordate {

}
