package samples.animal;

public interface Terrestrial {
	
	void walk();
}
