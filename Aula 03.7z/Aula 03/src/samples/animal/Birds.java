package samples.animal;

public abstract class Birds extends Chordate implements Aerial,Terrestrial {

}
