package samples.animal;

public abstract class Chordate extends Animal{
	
	public Chordate()
	{}	
	
	public Chordate(String scientificName,String popularName,int age,double mass) {
		super(scientificName,popularName,age,mass);
		
	}
	
}
