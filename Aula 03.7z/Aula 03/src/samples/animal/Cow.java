package samples.animal;

public class Cow extends Mammal{
	
	public void born() {
		System.out.println("Whale Nascendo");

	}
	
	public void eat() {
		System.out.println("Whale Comendo");
	
	}

	public void grows() {
		System.out.println("Whale Crescendo");
	
	}

	public void reproduces() {
		System.out.println("Whale Reproduzindo");
		
		
	}
	
	public void die() {
		System.out.println("Whale Falecendo");
		
		
	}

	@Override
	public void walk() {
		System.out.println("Whale Andando");
		
	}

	
}
