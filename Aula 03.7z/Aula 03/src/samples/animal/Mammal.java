package samples.animal;

public abstract class Mammal extends Chordate implements Terrestrial  {

}
