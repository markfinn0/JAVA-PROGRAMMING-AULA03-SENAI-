package samples.animal;

public interface Aerial {
	
	void fly();
}
