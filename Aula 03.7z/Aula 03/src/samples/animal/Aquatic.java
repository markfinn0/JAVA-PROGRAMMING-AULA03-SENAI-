package samples.animal;

public interface Aquatic {
	
	void swing();
}
