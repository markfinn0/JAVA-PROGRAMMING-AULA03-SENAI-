package auxiliary;
import java.util.List;
import java.util.ArrayList;

import java.util.Scanner;
import main.ImmutableClass;
import main.Enumeration;
import main.Register;
import main.AbstractClass;

import main.ConcreteClass;
import main.ConcreteClass1;
import main.ConcreteClass2;
import main.Tools;

import main.*;




public class AuxiliaryTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Início do Roteiro 1");
		ConcreteClass1 cc1 = new ConcreteClass1(); //Chamada do método construtor....
		ConcreteClass2 cc2 = new ConcreteClass2(); //Chamada do método construtor....
		
		System.out.println(cc1.getPassword());
		//System.out.println(cc2.password);
		
		System.out.println("fim do Roteiro 1");
		
		System.out.println("................");
		
		System.out.println("Início do Roteiro 2");
		
		
		//COM POLIMORFISMO
		AbstractClass ac1=new ConcreteClass();
		System.out.println(ac1.password);
		
		
		//SEM POLIMORFISMO
		ConcreteClass ac2=new ConcreteClass();
		System.out.println(ac2.password);
		
		
		ac1.sayHello();
		ac2.sayHello();
		ac2.originalSayHello();
		ac2.sayHi();
		ac1.sayHi();

		System.out.println("fim do Roteiro 2");
		
		
		
		System.out.println("................");
		System.out.println("Início do Roteiro 4");
		
		
		ConcreteClass cc3=new ConcreteClass();
		
		System.out.println(ac1.interfaceVar);
		
		System.out.println(cc3.interfaceVar);
		
		AuxiliaryClass aux = new AuxiliaryClass();
		
		//aux.interfaceVar=false; Não é permitido
		
		System.out.println(aux.interfaceVar);
		ac1.InterfaceMethod1();
		System.out.println("fim do Roteiro 4");

		
		
		System.out.println("................");
		System.out.println("Início do Roteiro 6");
		/*Tools T2=new Tools();
		Tools T3=new Tools();
		
		T2.option='B';
		T3.option='C';
		
		System.out.println(T2.option);
		System.out.println(T3.option);
		
		Tools.option='D';
		System.out.println(Tools.option);
		Tools.printOption();
		
		T2.alternative='B';
		T3.alternative='C';
		System.out.println(T2.alternative);
		System.out.println(T3.alternative);*/	
		
		Tools.display("Teste");
		Tools.display(25.32);
		Tools.display(25.36566565656542);
		Object value=Tools.sum(50430, 67009);
		
		System.out.println(value);
		
		System.out.println("fim do Roteiro 6");
		
		System.out.println("................");
		System.out.println("Início do Roteiro 7");
		
		ConcreteClass2 cc4=new ConcreteClass2(8950);
		
		System.out.println(cc4);
		System.out.println("fim do Roteiro 7");
		
		System.out.println("................");
		System.out.println("Início do Roteiro 8");
		
		Enumeration test = Enumeration.ENUM_OBJECT_1;
		
		System.out.println(test);
		System.out.println(Enumeration.ENUM_OBJECT_2);
		//Enumeration.ENUM_OBJECT_1.value1=100;
		//System.out.println(Enumeration.ENUM_OBJECT_1);
		//System.out.println(Enumeration.ENUM_OBJECT_1.getValue1());


		for (int i=0;i<Enumeration.values().length;i++) {
			System.out.println(Enumeration.values()[i]);
		}
		
		for (Enumeration enumTemp:Enumeration.values()) {
			System.out.println(enumTemp);
			System.out.println(enumTemp.getValue1());
			System.out.println(enumTemp.getValue2());
		}
		System.out.println("fim do Roteiro 8");
		
		System.out.println("................");
		System.out.println("Início do Roteiro 9");
		
		//Polimorfismo
		List<String> habitat = new ArrayList<>();
		habitat.add("Florestas Tropicais");
		habitat.add("Florestas Deciduas");
		habitat.add("Bosques de Arbustos");
		habitat.add("Terra Firme");
		habitat.add("Savanas");
		
		
		ImmutableClass HABITAT=new ImmutableClass("Galeocerdo cuvier","Tubarão Tigre",20,50,habitat);
		
		habitat.add("OCEANOS");
		
		System.out.println(HABITAT);
		
		ImmutableClass IC2=new ImmutableClass("Galeocerdo cuvier","Tubarão Tigre",20,50,habitat);
		System.out.println(IC2);
		
		
		ConcreteClass2 cc5=new ConcreteClass2(8950);
		ConcreteClass2 cc6=new ConcreteClass2(8950);
		
		
		System.out.println("fim do Roteiro 9");
		
		System.out.println("................");
		System.out.println("Início do Roteiro 10");
		
		
		List<String> habitat2 = new ArrayList<>();
		habitat2.add("Florestas Tropicais");
		habitat2.add("Florestas Deciduas");
		habitat2.add("Bosques de Arbustos");
		habitat2.add("Terra Firme");
		habitat2.add("Savanas");
			
		Register reg1=new Register("Galeocerdo cuvier","Tubarão Tigre",20,50,habitat2);
		habitat2.add("OCEANOS");
		
		System.out.println(reg1);
		
		System.out.println(reg1.toString());
		
		System.out.println("fim do Roteiro 10");
		
		System.out.println("................");
		
		System.out.println("Início do Roteiro 11");
//		GenericClass gc1=new GenericClass();
//		
//		System.out.println(gc1.getPassword());
//		
//		Object password = gc1.getPassword();
//		
//		
//		password= (int)password +1111;
		
	
		//gc1.setPassword("senha");
		//System.out.println(password);
		
		GenericClass<String> gc2 = new GenericClass<>();
		gc2.setPassword("senha");
		
		System.out.println(gc2.getPassword());
		
		GenericClass<Object> gc3 = new GenericClass<>();
		
		gc3.setPassword(1500);
		
		System.out.println(gc3.getPassword());
		
		
		GenericClass2<Integer,String> gc5 = new GenericClass2<>();
		
		gc5.setPassword(1500);
		
		gc5.setdescription("ejgrejgreglkre");
		
		
		Tools.display("Teste");
		Tools.display(25.32);
		Tools.display(25.36566565656542);
		Object value3=Tools.sum(50430, 67009);
		
		
		
	}

}
