package auxiliary;
import main.Interface1;
import main.Interface2;

public class AuxiliaryClass implements Interface1,Interface2 {

	@Override
	 public void InterfaceMethod2()
	{
		System.out.println("método 1 da interface");
		
		
	};
	
}
